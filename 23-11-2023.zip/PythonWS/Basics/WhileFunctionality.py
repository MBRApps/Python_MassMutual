a=int(input('Enter First Value:'))
b=int(input('Enter Second Value:'))
x=True

while x:
    n=int(input('1.Add\n2.Sub\n3.Mul\n0.Exit\nEnter Your Choice:'))
    if n==0:
        x=False
    elif n==1:
        print(a+b)
    elif n==2:
        print(a-b)
    elif n==3:
        print(a*b)
    else:
        print('Incorrect Input!')