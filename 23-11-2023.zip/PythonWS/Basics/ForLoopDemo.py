n=int(input('Enter a Value:'))

for i in range(1,n+1,1):
    #print('Hello')
    print(i)