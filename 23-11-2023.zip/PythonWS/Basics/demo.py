a=15
b=29

# print(a==b)
# print(a>=b)
# print(a>b)
# print(a<b)
# print(a<=b)
# print(a!=b)

# print(True and True)
# print(False and True)
# print(False and False)

# print(True or True)
# print(False or True)
# print(False or False)

# print(not True)


x=15
print(x)

x+=10
print(x)

x-=10
print(x)





