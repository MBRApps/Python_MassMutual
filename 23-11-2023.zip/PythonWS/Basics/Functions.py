def printValue(val):
    print(val)

def sum(a,b):
    return a+b

printValue(10)
printValue('india')

result=sum(10,20)
print(result)

def testfn(inp):
    inp.append(40)

arr=[10,20,30]

res=testfn(arr)
print(arr)
