class Parent1:
    def printMsg(self):
        print('This is From Parent-1 Class')

class Parent2:
    def displayMsg(self):
        print('This is From Parent-2 Class')

class Child(Parent1,Parent2):
    def showMsg(self):
        print('This is From Child Class')

child=Child()
child.printMsg()
child.displayMsg()
child.showMsg()


        