n=int(input('Enter a Value:'))

for i in range(1,11):
    print(n-1,' X ',i,' = ',(n-1)*i,end=3*'\t')
    print(n,' X ',i,' = ',n*i,end=3*'\t')
    print(n+1,' X ',i,' = ',(n+1)*i)