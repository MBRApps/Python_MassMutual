n=int(input('Enter a Value:'))

for i in range(1,11):
    print(n,' X ',i,' = ',n*i)