a=int(input('Enter First Value:'))
b=int(input('Enter Second Value:'))
c=int(input('Enter Third Value:'))

if a>b and a>c:
    print(str(a)+"")
    print(f"{a} is Bigger!")
elif b>c:
    print(f"{b} is Bigger!")
else:
   print(f"{c} is Bigger!")