class BankV1:
    def withdraw(self,amount):
        print('Withdraw using NetBanking')

class BankV2(BankV1):
    def withdraw(self, amount):
        print('Withdraw using UPI')

v1=BankV1()
v2=BankV2()

v1.withdraw(5000)
v2.withdraw(9500)