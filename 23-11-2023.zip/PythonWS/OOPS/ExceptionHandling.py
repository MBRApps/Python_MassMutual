try:    
    print("-----------try-----------------")
    i=int(input('Enter a Number:'))
    i=i+1
    print(f"After Increment:{i}")
except ValueError as ex:
    print("-----------Catch-----------------")
    print("Incorrect Value Received")
except Exception as ex:
    print("-----------Catch-----------------")
    print(ex)
finally:
    print("-----------Finally-----------------")
    print()