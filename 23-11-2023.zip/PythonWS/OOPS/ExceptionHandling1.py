try:
    a=int(input('Enter First Number:'))
    b=int(input('Enter Second Number:'))
    result=a/b
    print(result)
except ZeroDivisionError as ex:
    print("can't divide with Zero!")