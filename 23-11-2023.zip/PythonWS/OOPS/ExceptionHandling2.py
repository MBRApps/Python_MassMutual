try:
    arr=['C','C++','Java','Python','Ruby']
    ind=int(input('Enter Index:'))
    print(arr[ind])
except IndexError as ex:
    print(ex)