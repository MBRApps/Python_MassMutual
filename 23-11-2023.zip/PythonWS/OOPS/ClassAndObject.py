class Product:
    Id=0
    Title=""
    Price=0.0

    def __init__(self,id,title,price):
        self.Id=id
        self.Title=title
        self.Price=price

    def printProduct(self):
        print(f"{self.Id}-{self.Title}-{self.Price}")

#creating an object
prod1=Product(101,'Iphone 15',75000)

print(prod1.Id)
print(prod1.Title)
print(prod1.Price)
prod1.printProduct()