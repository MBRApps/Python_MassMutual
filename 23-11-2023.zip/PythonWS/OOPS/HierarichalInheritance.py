class Parent:
    def sayHi(self):
        print('hi')

class Child1(Parent):
    def sayHello(self):
        print('Hello')

class Child2(Parent):
    def sayBye(self):
        print('Bye')

c1=Child1()
c2=Child2()

c1.sayHi()
c2.sayHi()