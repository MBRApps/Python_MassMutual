class InsuffecientFundsException(Exception):
    def __init__(self,msg):
        super().__init__(msg)


try:
    accBal=25000
    amount=int(input('Enter Amount to withdraw:'))
    if amount<=accBal:
        accBal-=amount
        print(f'Transaction is Successfull! Available Balance:{accBal}')
    else:
        raise InsuffecientFundsException('No Suffecient Balance in Account!')
except Exception as ex:
    print(ex)