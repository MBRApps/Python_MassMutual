class Parent:
    def printMsg(self):
        print('This is From Parent Class')


class Child(Parent):
    def showMsg(self):
        print('This is From Child Class')

parent=Parent()
child=Child()

parent.printMsg()
child.showMsg()
child.printMsg()

        