try:
    a="15"
    result=a+18
    print(result)
except TypeError as ex:
    print(ex)