class Demo:
    def _printMsg(self):
        print("Hello")
class Child(Demo):
    def printParentMsg(self):
        self._printMsg()

# demo=Demo()
# demo.printMsg()

child=Child()
child.printParentMsg()

    