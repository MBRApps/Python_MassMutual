from abc import ABC,abstractmethod
class Arithematics(ABC):
    def sum(self,a,b):
        print(a+b)

    def sub(self,a,b):
        print(a-b)

    @abstractmethod
    def mul(self,a,b):
        pass

class Sample(Arithematics):
    def mul(self,a,b):
        print(a*b)

sample=Sample()
sample.sum(10,20)
sample.sub(10,20)
sample.mul(10,20)