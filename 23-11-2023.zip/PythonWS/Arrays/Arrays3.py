arr=[10,15.63,True,'V',"india"]

for x in arr:
    if isinstance(x,str):
        print(x,' -  ',type(x))