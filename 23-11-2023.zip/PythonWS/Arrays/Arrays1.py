from array import array

CoursesArr=["C","C++","Java","Python","SQL"]
#CoursesArr=array('i',[98,88,99,90,76,55])
print(CoursesArr)

for i in range(0,len(CoursesArr)):
    print(CoursesArr[i])