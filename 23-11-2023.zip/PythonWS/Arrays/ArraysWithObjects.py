class Product:
    def __init__(self,id,name,price) -> None:
       self.Id=id
       self.Name=name
       self.Price=price

ProductList=[]

#adding Product
prod=Product(1,'Iphone 15',98000)
ProductList.append(prod)

prod1=Product(2,'Iphone 14',76000)
ProductList.append(prod1)

#printing all products
def PrintData():
    for pr in ProductList:
        print(f"{pr.Id}-{pr.Name}-{pr.Price}")

PrintData()
#update Product
prod2=ProductList[1]
prod2.Name="Samsung S23 Ultra"

PrintData()

#Delete Product
ProductList.remove(ProductList[1])
PrintData()
