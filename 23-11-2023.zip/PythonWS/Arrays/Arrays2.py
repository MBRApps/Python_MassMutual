courses=[]

n=int(input('Enter Array Size:'))

#reading array values
for i in range(n):
    val=input(f'Enter value for Position-{i}:')
    courses.append(val)

#printing array values
# for j in range(0,len(courses)):
#     print(courses[j])

for course in courses:
    print(course)
