import re

def validate_PAN(inp):
    pattern=r'^[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}$'
    if re.match(pattern,inp):
        print('Valid')
    else:
        print('Invalid')

mobile=input('Enter PAN No.:')
validate_PAN(mobile)

    