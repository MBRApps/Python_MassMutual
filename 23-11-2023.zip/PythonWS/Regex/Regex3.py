import re

def validate_UserId(inp):
    pattern=r'^[A-Za-z]{1}[A-Za-z0-9_$#.]{7,19}$'
    if re.match(pattern,inp):
        print('Valid')
    else:
        print('Invalid')

mobile=input('Enter UserId:')
validate_UserId(mobile)

    