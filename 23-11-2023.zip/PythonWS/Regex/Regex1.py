import re

def validate_mobile(inp):
    pattern=r'^[6-9]{1}[0-9]{9}$'
    if re.match(pattern,inp):
        print('Valid')
    else:
        print('Invalid')

mobile=input('Enter Mobile No.:')
validate_mobile(mobile)

    