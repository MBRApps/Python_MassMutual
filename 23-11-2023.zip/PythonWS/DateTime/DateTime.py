import datetime

print(datetime.datetime.now())
print(datetime.datetime(2005,5,22,10,25,59,256))

dt=datetime.datetime.now()
print(dt)
print(dt.date())
print(dt.time())
print(dt.year)
print(dt.month)
print(dt.day)
print(dt.hour)
print(dt.minute)
print(dt.second)
print(dt.microsecond)

print(dt.strftime('%Y/%b/%d %H:%M:%S'))
result=dt+datetime.timedelta(days=10890)
print(result)

dt1=datetime.datetime.now()
diff=result-dt1
print(diff.days)

print(dt.strftime('%Y%m%d%H%M%S'))

