courses=['C','C++','Java','SQL']
print(courses)

courses[1]='Python'
print(courses)