userdata={
    'name':'Steve Jobs',
    'age':25,
    'city':'Delhi'
}

userdata.pop('age')
userdata.update({'city':'Mumbai'})
userdata.clear()

print(userdata.keys())
print(userdata.values())