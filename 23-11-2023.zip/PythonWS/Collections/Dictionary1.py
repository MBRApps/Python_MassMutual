products={
    'mobiles':[
                {'Id':101,'Title':'Samsung S23','Price':98500},
                {'Id':102,'Title':'Samsung S23 FE','Price':66000},
                {'Id':103,'Title':'IPhone 15','Price':78000},
                {'Id':104,'Title':'Iphone 13 Mini','Price':58500},
         ],
    'Laptops':[
        {'Id':905,'Title':'Dell 9856','Price':39000},
        {'Id':996,'Title':'Dell 2585','Price':88000},
        {'Id':999,'Title':'Dell 1205','Price':79000}
    ]
}

for prod in products['mobiles']:
    print(prod)

for prod in products['Laptops']:
    print(prod)

#products['Laptops'][1]={}