s='i am from INDIA'
print(len(s))
print(s)

print(s.lower())
print(s.upper())
print(s.title())

s1=' india     '
print(s1.strip())

s1='$$$$$$$$$$india$$$$$$$$$$$$$$'
print(s1.strip('$'))

print(s.replace('m','$'))
print(s.replace('from','IN'))

print(s.split())
s1='i-am-from-india'
print(s1.split('-'))

print(s.find('m'))
print(s.index('m'))

print(s.startswith('i am'))
print(s.endswith('INDIA'))

s1='india'
s2='INDIA'
print(s1==s2)
print(s1.lower()==s2.lower())