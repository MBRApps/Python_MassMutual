import os

dirPath='D://Python//Sample//Demo//Test'

if os.path.exists(dirPath):
    fileList=os.listdir(dirPath)
    for file in fileList:
        print(file)
else:
    print('Wrong Path/Path Not Exist!')