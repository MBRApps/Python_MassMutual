filePath='D:\\sample.txt'
lines=[]
with open(filePath,'r') as file:
    lines=file.readlines()

for line in lines:
    print(line)
