import os
filePath='D:\\sample.txt'

fileName=os.path.basename(filePath)
print(fileName)

size=os.path.getsize(filePath)
print(f'{size} Bytes')

extension=os.path.splitext(filePath)[1]
print(extension)

print(os.path.abspath(filePath))
print(os.path.dirname(filePath))