import os

dirPath='D://Python//Sample//Demo//Test'
os.makedirs(dirPath)

if os.path.exists(dirPath):
    print('Dir(s) Created Successfully!')
else:
    print('something went Wrong!')