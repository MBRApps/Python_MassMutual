filePath='D:\\sample.txt'

with open(filePath,'r+') as file:
    file.write('This is From Line-1\n')
    file.write('This is From Line-2\n')
    file.write('This is From Line-3\n')
    file.write('This is From Line-4\n')
    file.write('This is From Line-5\n')
    file.write('This is From Line-6\n')

# lines=['Line-1','Line-2','Line-3','Line-4']
# with open(filePath,'w') as file:
#     file.writelines(lines)