import shutil,os
sfilePath='D://demo.txt'
dfilePath='D://Python//Sample//Demo//Test//sample.txt'

shutil.copy(sfilePath,dfilePath)
if os.path.exists(dfilePath):
    print('File Copied Successfully')
else:
    print('OOPS Something went Wrong!')
