import os

sfilePath='D:\\sample.txt'
dfilePath='D:\\demo.txt'

os.rename(sfilePath,dfilePath)

if os.path.exists(dfilePath):
    print('File Renamed Successfully!')
else:
    print('OOPS Somethong Went Wrong!')

