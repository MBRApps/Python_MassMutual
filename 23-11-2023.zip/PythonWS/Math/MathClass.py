import math

print(math.pi)
print(math.pow(2,3))
print(math.sqrt(25))
print(math.sin(98.25))
print(math.log(25))
print(math.floor(10.59))
print(math.floor(10.99))
print(math.ceil(10.59))
print(math.ceil(10.99))